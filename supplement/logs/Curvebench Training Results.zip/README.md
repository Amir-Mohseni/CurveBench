# CurveBench Training Results — W&B LaTeX Export

This directory was exported from the CurveBench W&B training report.
The original report URL has been removed for anonymous review.

All charts are rendered as high-resolution PNGs in the **charts/** directory.

## Sections

- **Section 2** (Panels 0–6): Main training curves (total reward, tree reward, node count reward)
- **Section 6** (Panels 0–33): Per-run and per-model breakdowns
- **Section 8** (Panels 0–46): Evaluation metrics across splits and categories

## Rendering

Upload this directory to [Overleaf](https://www.overleaf.com/) (New Project → Upload Project),
or compile locally:

```bash
pdflatex report.tex
```

Requirements: any standard TeX distribution (TinyTeX, TexLive, BasicTeX, MiKTeX).

## Model Labels

Run names in the charts correspond to anonymized labels:
- `model-a` — qwen3-vl-8b-rlvr (8B, GRPO)
- `model-b` — qwen3-vl-30b-a3b-rlvr (30B, GRPO)
